#include <stdio.h>

#define N 10

int mystrlen(char *string);
char *mystrrevcopy(char *src, char *dest);

int main(int argc, char *argv[]) {
	char buf[N];
	if (argc != 3) {
		printf("Nebyly zadany 2 retezce!\n");
		return 1;
	}
	printf("Delka prvniho retezce (tj. %s): %u\n", argv[1], mystrlen(argv[1]));
	printf("Delka druheho retezce (tj. %s): %u\n", argv[2], mystrlen(argv[2]));
	if ((mystrlen(argv[1]) + mystrlen(argv[2])) > N) {
		printf("Nedostatecna velikost pole!\n");
		return 2;
	}
	char *ptr = mystrrevcopy(argv[1], buf);
	mystrrevcopy(argv[2], ptr);
	printf("Vysledek revezovani a spojeni: %s\n", buf);
}

int mystrlen(char *string) {
	if (string == NULL) return -1;
	int counter = 0;
	while (string[counter] != '\0') counter++;
	return counter;
}

char *mystrrevcopy(char *src, char *dest) {
	if (src == NULL || dest == NULL) return NULL;
	unsigned size = mystrlen(src);
	for (unsigned u = 0; u < size; u++) {
		dest[u] = src[size - u - 1];
	}
	dest[size] = '\0';
	return &dest[size];
}